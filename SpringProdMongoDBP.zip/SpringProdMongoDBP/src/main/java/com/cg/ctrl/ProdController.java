package com.cg.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;

@RestController

@RequestMapping("/proddemo")
public class ProdController {

	@Autowired
	ProductDao prodDao;
	
	@PostMapping(value="/create/",consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",produces=MediaType.APPLICATION_JSON_VALUE)
	public String createProd(@RequestBody Product prod) 
	{
		prodDao.save(prod);
		return "Data Inserted in MongoDB";
	}
	
	@GetMapping(value="/fetchAllProd/", produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Product> fetchAllProd(){
		return prodDao.findAll();
	}
	
	@DeleteMapping(value="/deleteProduct/{pid}",produces=MediaType.APPLICATION_JSON_VALUE)
	public Product deleteProductById(@PathVariable("pid") String prodId)
	{
		Product prod=prodDao.findById(prodId).get();
		prodDao.deleteById(prodId);
		return prod;
		
	}
	
	@PutMapping(value="/updateProduct/{pid}",consumes=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",produces=MediaType.APPLICATION_JSON_VALUE)
	public Product updateProductInfo(@RequestBody Product prod,@PathVariable("pid") String prodId) {
		
		prod.setId(prodId);
		prodDao.save(prod);
		return prod;
	}
	
	@GetMapping("/fetchProdById/{id}")
	public Product read(@PathVariable("id") String id) {
		
		return prodDao.findById(id).get();
}
}
