package com.cg.dao;

import java.awt.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.bean.Product;

@Repository
public interface ProductDao extends MongoRepository<Product, String> {

  
}
